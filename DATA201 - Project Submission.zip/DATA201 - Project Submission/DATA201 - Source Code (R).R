# DATA201 - DATA WRANGLING

# Lecturer: Thomas Li, Taylor Winter

# ==================================

# GROUP PROJECT: Basketball Game (NBA)

# Students: 
#       Albert Zhong - 76329912 (yzh426)
#       Bang Vu - 81284510 (bvu16)
#       Richard McNulty - 16921640 (rmc228)
#       Ryan Robinson - 12396361 (rro96)

# Link to our GitHub repository: https://github.com/Albertooo666/Albert

# ==================================

# First, we need to import some packages

library(rvest) # popular R package used for web scraping
library(tidyverse) # useful for data manipulation, visualization, and analysis
library(magrittr) # for better handling of the pipe operator
library(purrr) # useful for iterating over elements, mapping functions, and working with lists and data frames
library(glue) # useful for string interpolation and templating
library(stringr) # useful for working with strings (manipulation, pattern matching, ...)
library(remotes) # useful for installing packages from a remote source (GitHub, GitLab, ...) 
library(polite) # the "polite" version of rvest, useful for working with web APIs
library(xml2) # useful for working with XML and HTML documents


# Assigning the webpage content to "url" varible
url <- "https://en.wikipedia.org/wiki/List_of_National_Basketball_Association_career_scoring_leaders"
# Reading and parsing the content of the webpage
nba <- read_html(url)

# Checking the data type of 'page' and getting a summary info of "nba"
nba %>% typeof()
nba %>% glimpse()
nba
nba %>% html_structure()

# Writing .title, with the dot because we want all results with that tag.
# Trying removing it and see what happens.re
nba %>%
  html_nodes(xpath = '//*[@class="vcard"]/span[@class="fn"]/a') # selecting elements of "vcard" class


# Extracting names from the webpage
player_name <- nba%>%
  html_nodes(xpath = '//*[@class="vcard"]/span[@class="fn"]/a') %>% # Selecting the HTML elements with class "vcard"
  html_text()  # Extracting the text content
player_name

# Building the Title variable using the code we used above
SLS_df <- tibble(Association = "NBA",
                 Names = player_name) 
SLS_df

# Extracting the attributes of the selected HTML elements, including the 'href' attribute which contains the URLs
nba %>%
  html_nodes(xpath = '//*[@class="vcard"]/span[@class="fn"]/a') %>%
  html_attrs() %>%
  glimpse()

# Extracting all anchor elements with class "vcard", 
nba %>%
  html_nodes(xpath = '//*[@class="vcard"]/span[@class="fn"]/a') %>%
  html_attrs() %>%
  map_chr("href") %>%
  paste0("https://en.wikipedia.org/", .)

# Extracting the total points scored by NBA players,
# then selecting the top 50 points
total_points <- nba %>%
  html_nodes("td:nth-child(5)") %>%
  html_text() %>%
  str_replace_all("\n", "") 
top_50_points <- head(total_points, 50)
top_50_points

# Updating the 'SLS_df' dataframe by adding two new columns: 'Link' and 'Points'
SLS_df %<>% 
  # Extract the 'href' attribute from the anchor elements with class 'vcard'
  mutate(Link = nba %>% html_nodes(xpath = '//*[@class="vcard"]/span[@class="fn"]/a') %>% html_attr("href") ,Points = top_50_points)

SLS_df

# Using FOR loop to add each link in LINK column with "https://en.wikipedia.org/""
for (i in 1:50)
{
  full_link <- paste0("https://en.wikipedia.org/", SLS_df[i,3])
  SLS_df[i,3] <- full_link
}

# Creating a variable 'url_link' using the first value from the 'Link' column of 'SLS_df'
url_link<- glue(SLS_df$Link[1])
url_link

# Extracting info about the player's position
position <- url_link %>%
  read_html() %>%
  html_node(".infobox-data.role") %>%
  html_text()
position

# Extracting information about the NBA player's team
team <- url_link %>%
  read_html() %>%
  html_node("th.infobox-header") %>%
  html_text()
team

# Extracting the table in the webpage as a dataframe
stat_table <- url_link %>%
  read_html() %>%
  html_element("table.wikitable") %>%
  html_table()

stat_table

# Getting the information needed for the "stat_table"
ppg <- stat_table[nrow(stat_table) - 1, ncol(stat_table)] # getting Points Per Game
ppg
gp<- stat_table[nrow(stat_table) - 1,3] # getting Games Played
gp
mp <- stat_table[nrow(stat_table) - 1,5] # getting Minutes Played
mp

head(stat_table)

view(stat_table)


# Create 3 empty vectors
ppg_vector <- c()
gp_vector <- c()
mp_vector <- c()

# Looping through the list of NBA players to get the values we need

for(i in 1:50)
{
  url_link <- SLS_df[[i,3]]
  stat_tables <- url_link %>%
    read_html() %>%
    html_nodes("table") %>%
    html_table()
  
  ppg <- NA
  gp <- NA
  mp <- NA
  
  for(j in 1:length(stat_tables)) {
    stat_table <- stat_tables[[j]]
    
    career_row_num <- 0
    
    # Checking if the table contains the required columns and header
    if("PPG" %in% colnames(stat_table) && "GP" %in% colnames(stat_table)) {
      
      for (j in 1:nrow(stat_table)) {
        if (grepl("areer", stat_table[j,1]))
        {
          career_row_num <- j
        }
      }
      
      if(!is.null(row_number) && !career_row_num == 0) {
        PPG_Num <- grep("PPG", colnames(stat_table))[1]
        GP_Num <- grep("GP", colnames(stat_table))[1]
        MP_Num <- grep("MPG", colnames(stat_table))[1]
        if (is.na(MP_Num))
        {
          MP_Num <- grep("MIN", colnames(stat_table))[1]
        }
        
        ppg <- stat_table[career_row_num,PPG_Num]
        gp<- stat_table[career_row_num,GP_Num]
        mp <- stat_table[career_row_num,MP_Num]
        
        break # Breaking the loop if all the values we need are successfully found.
      }
      
    }
  }
  
  # Appending the values to the vectors
  ppg_vector <- c(ppg_vector, ppg)
  gp_vector <- c(gp_vector, gp)
  mp_vector <- c(mp_vector, mp)
}

# Adding the vectors as new columns to the "SLF_df" dataframe
SLS_df$PPG <- ppg_vector
SLS_df$GP <- gp_vector
SLS_df$MP <- mp_vector

view(SLS_df)

# Looping through the dataframe to remove unwanted characters from the 4 columns: Points, PPG, GP and MP
# "," and "‡" are successfully removed from those columns.
for (i in 1:nrow(SLS_df))
{
  SLS_df$Points[i] <- gsub(pattern = "‡", "" ,SLS_df[[i,4]])
  SLS_df$Points[i] <- gsub(pattern = ",", "" ,SLS_df[[i,4]])
  
  SLS_df$PPG[i] <- gsub(pattern = "‡", "" ,SLS_df[[i,5]])
  SLS_df$PPG[i] <- gsub(pattern = ",", "" ,SLS_df[[i,5]])
  
  SLS_df$GP[i] <- gsub(pattern = "‡", "" ,SLS_df[[i,6]])
  SLS_df$GP[i] <- gsub(pattern = ",", "" ,SLS_df[[i,6]])
  
  SLS_df$MP[i] <- gsub(pattern = "‡", "" ,SLS_df[[i,7]])
  SLS_df$MP[i] <- gsub(pattern = ",", "" ,SLS_df[[i,7]])
}

# Converting values of 4 columns (Points, PPG, GP, MP) into numeric data type.
SLS_df <- SLS_df %>%
  mutate(Points = as.numeric(Points),
         PPG = as.numeric(PPG),
         GP = as.numeric(GP),
         MP = as.numeric(MP))

# Now we have got the "clean" data, ready for plotting.

plot(SLS_df$MP, SLS_df$PPG)
abline(lm(PPG~MP, data = SLS_df), col = "red")

# PLOTS

# Plot 1: Relationship between Points per Game is (PPG) and Points scored

# Observation: Top scores tends have played around 1300 to 1600 games, 
# Outliner: One player played over 1600 games but the points he scored was low.

ggplot(data = SLS_df,
       aes(x = GP, y = Points)) +
  geom_point() +
  labs(title = "Points Per Game vs Points Scored", x = "Games Played", y = "Points")

# Plot 2: Relationship between Minutes per Game (MPG) and Points per Game (PPG)

# Fitting a line with geom_smooth, make it straight with method = "lm"
# Observation: Positive relationship. 
    # Players who play more minutes tend to score more points. 

ggplot(data = SLS_df,
       aes(MP, PPG)) + 
  geom_point()+
  geom_smooth(method='lm', se = F)+
  labs(title = "Minutes per Game against Points per Game",
       xlab = "MPG")

# Plot 3: Relationship between Points per Game and Games Played

# Observation: Negative relationship. 
    # As a player's career continues, they tend to score less points.

ggplot(data = SLS_df[-50,],
       aes(x = GP, y = PPG)) +
  geom_point() +
  geom_smooth()+
  labs(title = "Points Per Game vs Games Played", x = "Games Played", y = "Points Per Game")

# Plot 4:  Relationship between Points and MP
# Observation:  Players who play around 36-38 minutes per game tend to score more points.

ggplot(data = SLS_df, 
       aes(x = MP, y = Points)) +
  geom_smooth() +
  geom_point() +
  labs(title = "Points vs MP", x = "MP", y = "Points")


# ===== THE END ==== #






